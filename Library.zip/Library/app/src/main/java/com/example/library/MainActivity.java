package com.example.library;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.EditText;
import android.widget.ListView;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity implements AdapterView.OnItemClickListener{
    ListView bookList;
    ArrayList<Book> books = new ArrayList<Book>();
    public static int ISBN;
    public static String title;
    public static String author;
    public static String publisher;
    public static int year;
    public static int img;
    public static String buttonB;

    public void fillBooks(){
        books.add(new Book(1234,"alchemist","poulo","rhonda",1999,R.drawable.book1,"more Details"));
        books.add(new Book(5678,"twilight","stephenie","atom",2018,R.drawable.book2,"more Details"));
        books.add(new Book(9012,"funeral","elijah","harper",2011,R.drawable.book3,"more Details"));
        books.add(new Book(3456,"wuthering","emily","harper",2001,R.drawable.book4,"more Details"));
        books.add(new Book(7890,"phoenix","tilly","joney",2005,R.drawable.book5,"more Details"));
        books.add(new Book(2456,"sinner","bhaavana","walker",1997,R.drawable.book6,"more Details"));
        books.add(new Book(8764,"tell me","ravinder","trident",2009,R.drawable.book7,"more Details"));
        }
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        bookList=findViewById(R.id.lvBooks);
        fillBooks();
        bookList.setAdapter(new BookAdapter(this, books));
        bookList.setOnItemClickListener(this);
    }


    //@Override
    public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
        ISBN = books.get(i).getBookISBN();
        title = books.get(i).getBookTitle();
        author = books.get(i).getBookAuthor();
        publisher = books.get(i).getBookPublisher();
        year = books.get(i).getBookYear();
        img = books.get(i).getBookImage();
        buttonB = books.get(i).getBookButton();


        Intent intent = new Intent(this,Pop.class);
        startActivity(intent);

    }
}
