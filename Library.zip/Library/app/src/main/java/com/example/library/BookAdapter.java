package com.example.library;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;

import android.widget.TextView;

import java.util.ArrayList;

public class BookAdapter extends BaseAdapter {
    private ArrayList<Book> bookDetails;
    LayoutInflater layoutInflater;

    public BookAdapter(Context context, ArrayList<Book> bookDetails) {
        this.bookDetails = bookDetails;
        layoutInflater = LayoutInflater.from(context);
    }


    public int getCount() {
        return bookDetails.size();
    }


    public Object getItem(int i) {
        return bookDetails.get(i);
    }


    public long getItemId(int i) {
        return i;
    }


    public View getView(int i, View view, ViewGroup viewGroup) {
        ViewHolder holder;
        if(view==null){
            holder = new ViewHolder();
            view = layoutInflater.inflate(R.layout.list_row,null);
            holder.tvISBN=view.findViewById(R.id.tvBookISBN);
            view.setTag(holder);
        }
        else
            holder =(ViewHolder) view.getTag();

        holder.tvISBN.setText(String.format("%d",bookDetails.get(i).getBookISBN()));
        return view;
    }
    static class ViewHolder {
        TextView tvISBN;
     }
}
