package com.example.library;

public class Book {
    private int bookISBN;
    private String bookTitle;
    private String bookAuthor;
    private String bookPublisher;
    private int bookYear;
    private int bookImage;
    private String bookButton;


    public Book(int bookISBN,String bookTitle,String bookAuthor,String bookPublisher,int bookYear,int bookImage,String bookButton) {

        this.bookISBN = bookISBN;
        this.bookTitle = bookTitle;
        this.bookAuthor = bookAuthor;
        this.bookPublisher = bookPublisher;
        this.bookYear = bookYear;
        this.bookImage = bookImage;
        this.bookButton = bookButton;

    }


    public int getBookISBN() {

        return bookISBN;
    }

    public String getBookTitle() {
        return bookTitle;
    }

    public String getBookAuthor() {
        return bookAuthor;
    }

    public String getBookPublisher() {
        return bookPublisher;
    }

    public int getBookYear() {

        return bookYear;
    }

    public int getBookImage()
    {
        return bookImage;
    }

    public String getBookButton(){return bookButton;}
}

