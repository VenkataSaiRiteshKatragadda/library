package com.example.library;

import android.os.Bundle;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

public class BookDetailsActivity {
    EditText et1,et2,et3;
    TextView tv1;
    ImageView iv1;

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_book_details);
        tv1.setText(MainActivity.title);
        et1=findViewById(R.id.tvauthor);
        et1.setText(MainActivity.author);
        et2=findViewById(R.id.tvpublisher);
        et2.setText(MainActivity.publisher);
        et3=findViewById(R.id.tvyear);
        et3.setText(MainActivity.year);
        iv1=findViewById(R.id.imageView2);
        iv1.setImageResource(MainActivity.img);
    }



}
