package com.example.library;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

public class Pop extends Activity implements View.OnClickListener{

    TextView tv;
    ImageView iv;
    Button bn;

    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.popup);
        tv=findViewById(R.id.tvtit);
        tv.setText(MainActivity.title);
        iv=findViewById(R.id.imageView);
        iv.setImageResource(MainActivity.img);

        bn = findViewById(R.id.btndet);
        bn.setText(MainActivity.buttonB);
        bn.setOnClickListener(this);

        DisplayMetrics dm =new DisplayMetrics();
        getWindowManager().getDefaultDisplay().getMetrics(dm);

        int width = dm.widthPixels;
        int height = dm.heightPixels;

        getWindow().setLayout((int)(width*.8),(int)(height*.6));
    }
    public void onClick(View v) {
        if (v == bn)
        {
            Intent intent = new Intent(this, BookDetailsActivity.class);
            startActivity(intent);
        }
    }

}
